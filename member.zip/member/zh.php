﻿<?php

require_once(dirname(__FILE__)."/config.php");
CheckRank(0,0);
$menutype = 'config';
if(!isset($dopost)) $dopost = '';

$pwd2=(empty($pwd2))? "" : $pwd2;
$row=$dsql->GetOne("SELECT  * FROM `#@__member` WHERE mid='".$cfg_ml->M_ID."'");
$face = $row['face'];
if($dopost=='save')
{
    $svali = GetCkVdValue();

    if(strtolower($vdcode) != $svali || $svali=='')
    {
        ReSETVdValue();
        ShowMsg('Verification code error！','-1');
        exit();
    }
    if(!is_array($row) || $row['pwd'] != md5($oldpwd))
    {
        ShowMsg('The old password you entered is wrong or not filled in, it is not allowed to modify the information！','-1');
        exit();
    }
    if($userpwd != $userpwdok)
    {
        ShowMsg('The new password you entered two times is inconsistent！','-1');
        exit();
    }
    if($userpwd=='')
    {
        $pwd = $row['pwd'];
    }
    else
    {
        $pwd = md5($userpwd);
        $pwd2 = substr(md5($userpwd),5,20);
    }
    $addupquery = '';
    
    #api{{
    if(defined('UC_API') && @include_once DEDEROOT.'/uc_client/client.php')
    {
        $emailnew = $email != $row['email'] ? $email : '';
        $ucresult = uc_user_edit($cfg_ml->M_LoginID, $oldpwd, $userpwd, $emailnew);        
    }
    #/aip}}
    
    //修改安全问题或Email
    if($email != $row['email'] || ($newsafequestion != 0 && $newsafeanswer != ''))
    {
        if($row['safequestion']!=0 && ($row['safequestion'] != $safequestion || $row['safeanswer'] != $safeanswer))
        {
            ShowMsg('Your old security question and answer are incorrect, you cannot modify your email or security question！','-1');
            exit();
        }

        //修改Email
        if($email != $row['email'])
        {
            if(!CheckEmail($email))
            {
                ShowMsg('Email format is incorrect！','-1');
                exit();
            }
            else
            {
                $addupquery .= ",email='$email'";
            }
        }

        //修改安全问题
        if($newsafequestion != 0 && $newsafeanswer != '')
        {
            if(strlen($newsafeanswer) > 30)
            {
                ShowMsg('The answer to your new security question is too long, please keep it within 30 bytes！','-1');
                exit();
            }
            else
            {
			    $newsafequestion = HtmlReplace($newsafequestion,1);
			    $newsafeanswer = HtmlReplace($newsafeanswer,1);
                $addupquery .= ",safequestion='$newsafequestion',safeanswer='$newsafeanswer'";
            }
        }
    }

    //修改uname
    if($uname != $row['uname'])
    {
        $rs = CheckUserID($uname,'Nickname or company name',FALSE);
        if($rs!='ok')
        {
            ShowMsg($rs,'-1');
            exit();
        }
        $addupquery .= ",uname='$uname'";
    }
    
    //性别
    if( !in_array($sex, array('Male','female','confidential')) )
    {
        ShowMsg('Please choose a normal gender！','-1');
        exit();    
    }
    
    $query1 = "UPDATE `#@__member` SET pwd='$pwd',sex='$sex'{$addupquery} where mid='".$cfg_ml->M_ID."' ";
    $dsql->ExecuteNoneQuery($query1);

    //如果是管理员，修改其后台密码
    if($cfg_ml->fields['matt']==10 && $pwd2!="")
    {
        $query2 = "UPDATE `#@__admin` SET pwd='$pwd2' where id='".$cfg_ml->M_ID."' ";
        $dsql->ExecuteNoneQuery($query2);
    }
    // 清除会员缓存
    $cfg_ml->DelCache($cfg_ml->M_ID);
    ShowMsg('Successfully update your basic information！','zh.php',0,5000);
    exit();
}
include(DEDEMEMBER."/templets/zhanghao.htm");



