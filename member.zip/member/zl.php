﻿<?php

require_once(dirname(__FILE__).'/config.php');
require_once DEDEINC.'/membermodel.cls.php';
require_once(DEDEINC."/userlogin.class.php");
CheckRank(0,0);
require_once(DEDEINC.'/enums.func.php');
$menutype ='config';
if(!isset($dopost)) $dopost ='';

if($dopost=='')
{
    $dede_fields = empty($dede_fields)?'': trim($dede_fields);
    if(!empty($dede_fields))
    {
        if($dede_fieldshash != md5($dede_fields.$cfg_cookie_encode))
        {
            showMsg('Data verification is incorrect, the program returns','-1');
            exit();
        }
    }
    
    $dede_fieldshash = empty($dede_fieldshash)?'': trim($dede_fieldshash);
    $membermodel = new membermodel($cfg_ml->M_MbType);
    $modelform = $dsql->GetOne("SELECT * FROM #@__member_model WHERE id='$membermodel->modid' ");
    if(!is_array($modelform))
    {
        showmsg('Model form does not exist','-1');
        exit();
    }
    $row = $dsql->GetOne("SELECT * FROM ".$modelform['table']." WHERE mid=$cfg_ml->M_ID");
    if(!is_array($row))
    {
        showmsg("The record you visited does not exist or has not been audited",'-1');
        exit();
    }
    $postform = $membermodel->getForm('edit', $row,'membermodel');
    include(DEDEMEMBER."/templets/ziliao.htm");
    exit();
}
/*------------------------
function __Save()
------------------------*/
if($dopost=='save'){
    
        $membermodel = new membermodel($cfg_ml->M_MbType);
        $postform = $membermodel->getForm(true);

      //Complete the details here
        $dede_fields = empty($dede_fields)?'': trim($dede_fields);
        $dede_fieldshash = empty($dede_fieldshash)?'': trim($dede_fieldshash);
        $modid = empty($modid)? 0: intval(preg_replace("/[^\d]/",'', $modid));
        
        if(!empty($dede_fields))
        {
            if($dede_fieldshash != md5($dede_fields.$cfg_cookie_encode))
            {
                showMsg('Data verification is incorrect, the program returns','-1');
                exit();
            }
        }
        $modelform = $dsql->GetOne("SELECT * FROM #@__member_model WHERE id='$modid' ");
        if(!is_array($modelform))
        {
            showmsg('Model form does not exist','-1');
            exit();
        }
        
        $inadd_f ='';
        if(!empty($dede_fields))
        {
            $fieldarr = explode(';', $dede_fields);
            if(is_array($fieldarr))
            {
                foreach($fieldarr as $field)
                {
                    if($field =='') continue;
                    $fieldinfo = explode(',', $field);
                    if($fieldinfo[1] =='textdata')
                    {
                        ${$fieldinfo[0]} = FilterSearch(stripslashes(${$fieldinfo[0]}));
                        ${$fieldinfo[0]} = addslashes(${$fieldinfo[0]});
                    } else if ($fieldinfo[1] =='img')
                    {
                        ${$fieldinfo[0]} = addslashes(${$fieldinfo[0]});
                    }
                    else
                    {
                        if(empty(${$fieldinfo[0]})) ${$fieldinfo[0]} ='';
                        ${$fieldinfo[0]} = GetFieldValue(${$fieldinfo[0]}, $fieldinfo[1],0,'add','','diy', $fieldinfo[0]);
                    }
                    if($fieldinfo[0]=="birthday") ${$fieldinfo[0]}=GetDateMk(${$fieldinfo[0]});
                    $inadd_f .=','.$fieldinfo[0]." ='".${$fieldinfo[0]}."'";
                }
            }

        }
        $inadd_f=preg_replace('/,/','',$inadd_f,1);
        $query = "UPDATE `{$membermodel->table}`set {$inadd_f} WHERE mid='{$cfg_ml->M_ID}'";
        // clear cache
        $cfg_ml->DelCache($cfg_ml->M_ID);
        
        if(!$dsql->ExecuteNoneQuery($query))
        {
            ShowMsg("An error occurred while updating the additional table `{$membermodel->table}`, please contact the administrator!","javascript:;");
            exit();
        }else{
            ShowMsg('Update your details successfully!','zl.php',0,5000);
            exit();
        }
}

