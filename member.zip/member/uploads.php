﻿<?php

require_once(dirname(__FILE__)."/config.php");
CheckRank(0,0);
require_once(DEDEINC."/datalistcp.class.php");
setcookie("ENV_GOBACK_URL",$dedeNowurl,time()+3600,"/");
$menutype = 'content';
$keyword = empty($keyword) ? '' : FilterSearch($keyword);
$addsql = " where mid='".$cfg_ml->M_ID."' AND title LIKE '%$keyword%' ";
if(empty($mediatype)) $mediatype = 0;

$mediatype = intval($mediatype);
if($mediatype>0) $addsql .= " AND mediatype='$mediatype' ";

$sql = "SELECT * FROM `#@__uploads` $addsql ORDER BY aid DESC";
$dlist = new DataListCP();
$dlist->pageSize = 5;
$dlist->SetParameter("mediatype",$mediatype);
$dlist->SetParameter("keyword",$keyword);
$dlist->SetTemplate(DEDEMEMBER."/templets/uploadsssss.htm");
$dlist->SetSource($sql);
$dlist->Display();

function MediaType($tid,$nurl)
{
    if($tid==1)
    {
        return "image";
    }
    else if($tid==2)
    {
        return "FLASH";
    }
    else if($tid==3)
    {
        return "Video/audio";
    }
    else
    {
        return "Accessories/Other";
    }
}

function GetFileSize($fs)
{
    $fs = $fs/1024;
    return sprintf("%10.1f",$fs)." K";
}

function GetImageView($furl,$mtype)
{
    if($mtype==1)
    {
        return "<img class='litPic' width='80' height='80' src='$furl'  border='0' /><br />";
    }
}

