﻿<?php

require_once(dirname(__FILE__)."/config.php");
CheckRank(0,0);
if($cfg_mb_lit=='Y')
{
    ShowMsg("Because the system has opened the simplified version of the member space, the function you are accessing is not available!","-1");
    exit();
}
if($cfg_mb_album=='N')
{
    ShowMsg("Sorry, because the system has turned off the atlas function, the function you accessed is not available!","-1");
    exit();
}
require_once(DEDEINC."/dedetag.class.php");
require_once(DEDEINC."/customfields.func.php");
require_once(DEDEMEMBER."/inc/inc_catalog_options.php");
require_once(DEDEMEMBER."/inc/inc_archives_functions.php");
$channelid = isset($channelid) && is_numeric($channelid)? $channelid: 2;
$aid = isset($aid) && is_numeric($aid)? $aid: 0;
$menutype ='content';
if(empty($formhtml)) $formhtml = 0;

/*-------------
function _ShowForm(){}
--------------*/
if(empty($dopost))
{
    //Read archive information
    $arcQuery = "SELECT arc.*,ch.addtable,ch.fieldset,ch.arcsta
       FROM `#@__archives` arc LEFT JOIN `#@__channeltype` ch ON ch.id=arc.channel
       WHERE arc.id='$aid' AND arc.mid='".$cfg_ml->M_ID."'; ";
    $row = $dsql->GetOne($arcQuery);
    if(!is_array($row))
    {
        ShowMsg("Error reading document information!","-1");
        exit();
    }
    else if($row['arcrank']>=0)
    {
        $dtime = time();
        $maxtime = $cfg_mb_editday * 24 *3600;
        if($dtime-$row['senddate']> $maxtime)
        {
            ShowMsg("This document has been locked, you can no longer modify it!","-1");
            exit();
        }
    }
    $addRow = $dsql->GetOne("SELECT * FROM `{$row['addtable']}` WHERE aid='$aid'; ");
    $dtp = new DedeTagParse();
    $dtp->LoadSource($addRow['imgurls']);
    $abinfo = $dtp->GetTagByName('pagestyle');
    $row=XSSClean($row);$addRow=XSSClean($addRow);
    include(DEDEMEMBER."/templets/album_edit.htm");
    exit();
}
/*------------------------------
function _Save(){}
------------------------------*/
else if($dopost=='save')
{
    $svali = GetCkVdValue();
    if(preg_match("/1/",$safe_gdopen)){
        if(strtolower($vdcode)!=$svali || $svali=='')
        {
            ResetVdValue();
            ShowMsg('Verification code error!','-1');
            exit();
        }
    }
    $cInfos = $dsql->GetOne("Select * From `#@__channeltype`  where id='$channelid'; ");
    $maxwidth = isset($maxwidth) && is_numeric($maxwidth) ? $maxwidth : 800;
    $pagepicnum = isset($pagepicnum) && is_numeric($pagepicnum) ? $pagepicnum : 12;
    $ddmaxwidth = isset($ddmaxwidth) && is_numeric($ddmaxwidth) ? $ddmaxwidth : 200;
    $prow = isset($prow) && is_numeric($prow) ? $prow : 3;
    $pcol = isset($pcol) && is_numeric($pcol) ? $pcol : 3;
    $pagestyle = in_array($pagestyle,array('1','2','3')) ? $pagestyle : 2;

    include(DEDEMEMBER.'/inc/archives_check_edit.php');
    $imgurls = "{dede:pagestyle maxwidth='$maxwidth' pagepicnum='$pagepicnum'
    ddmaxwidth='$ddmaxwidth' row='$prow' col='$pcol' value='$pagestyle'/}\r\n";
    $hasone = false;
    $ddisfirst=1;

//Process and save the specified picture copied from the Internet
    if($formhtml==1)
    {
        $imagebody = stripslashes($imagebody);
        $imgurls .= GetCurContentAlbum($imagebody,$copysource,$litpicname);
        if($ddisfirst==1 && $litpic=='' && !empty($litpicname))
        {
            $litpic = $litpicname;
            $hasone = true;
        }
    }
    $info ='';

    //Check the uploaded or directly uploaded pictures
    for($i=1;$i<=120;$i++)
    {
        //Conditions for pictures
        if(isset(${'imgurl'.$i}) || (isset($_FILES['imgfile'.$i]['tmp_name']) && is_uploaded_file($_FILES['imgfile'.$i][' tmp_name'])))
        {
            $iinfo = str_replace("'","`",stripslashes(${'imgmsg'.$i}));
            if(!is_uploaded_file($_FILES['imgfile'.$i]['tmp_name']))
            {
                $iurl = stripslashes(${'imgurl'.$i});

                //If there is an old picture
                if(isset(${'imgurl'.$i}))
                {
                    $litpicname = $iurl;
                    $filename = $iurl;

                    //Thumbnail
                    if($pagestyle> 2)
                    {
                        $litpicname = GetImageMapDD($filename,$ddmaxwidth);
                        if($litpicname !='')
                        {
                            SaveUploadInfo($title.'small picture',$litpicname,1);
                        }
                    }
                }
                else
                {
                    continue;
                }
            }
            else
            {
                $sparr = Array("image/pjpeg","image/jpeg","image/gif","image/png","image/xpng","image/wbmp");
                if(!in_array($_FILES['imgfile'.$i]['type'],$sparr))
                {
                    continue;
                }
                if(isset(${'imgurl'.$i}))
                {
                    $filename = ${'imgurl'.$i};
                }
                else
                {
                    $filename ='';
                }
                $filename = MemberUploads('imgfile'.$i,$filename,$cfg_ml->M_ID,'image','',0,0,false);
                if($filename!='')
                {
                    SaveUploadInfo($title,$filename,1);
                }
                $litpicname = $filename;

                //Thumbnail
                if($pagestyle> 2)
                {
                    $litpicname = GetImageMapDD($filename,$ddmaxwidth);
                    if($litpicname !='')
                    {
                        SaveUploadInfo($title.'small picture',$litpicname,1);
                    }
                }
            }
            $imgfile = $cfg_basedir.$filename;
            if(is_file($imgfile))
            {
                $iurl = $filename;
                $info = '';
                $imginfos = @getimagesize($imgfile,$info);
                $imgurls .= "{dede:img ddimg='$litpicname' text='$iinfo' width='".$imginfos[0]."' height='".$imginfos[1]."'} $iurl {/dede:img}\r\n";
            }
            if(!$hasone && $litpic=='' && !empty($litpicname))
            {
                $litpic = $litpicname;
                $hasone = true;
            }
        }
}//End of loop
    $imgurls = addslashes($imgurls);

    //Analyze and process additional table data
    $inadd_f ='';
    if(!empty($dede_addonfields))
    {
        $addonfields = explode(';',$dede_addonfields);
        if(is_array($addonfields))
        {
            foreach($addonfields as $v)
            {
                if($v=='')
                {
                    continue;
                }
                $vs = explode(',',$v);
                if(!isset(${$vs[0]}))
                {
                    ${$vs[0]} ='';
                }
                ${$vs[0]} = GetFieldValueA(${$vs[0]},$vs[1],$aid);
                $inadd_f .=','.$vs[0]." ='".${$vs[0]}."' ";
            }
        }
        
        if (empty($dede_fieldshash) || $dede_fieldshash != md5($dede_addonfields.$cfg_cookie_encode))
        {
            showMsg('Data verification is incorrect, the program returns','-1');
            exit();
        }
        
        // Here is a verification of the additional data submitted by the front desk
        $fontiterm = PrintAutoFieldsAdd($cInfos['fieldset'],'autofield', FALSE);
        if ($fontiterm != $inadd_f)
        {
            ShowMsg("The submission form does not match the system configuration, please resubmit!", "-1");
            exit();
        }
    }
$description = HtmlReplace($description, -1);//2011.06.30 add html filtering (by: dream weaving fish)
    //Processing custom attributes of image documents
    if($litpic!='') $flag ='p';

    //Update the SQL statement of the database
    //Update the SQL statement of the database
    $upQuery = "UPDATE `#@__archives` SET
             ismake='$ismake',
             arcrank='$arcrank',
             typeid='$typeid',
             title='$title',
             litpic='$litpic',
             description='$description',
             keywords='$keywords',
             mtype='$mtypesid',
             flag='$flag'
        WHERE id='$aid' AND mid='$mid'; ";
    if(!$dsql->ExecuteNoneQuery($upQuery))
    {
        ShowMsg("An error occurred while saving the data to the database master table, please contact the administrator!".$dsql->GetError(),"-1");
        exit();
    }

    $isrm = 0;

    if($addtable!='')
    {
        $query = "UPDATE `$addtable`
      set typeid='$typeid',
      pagestyle='$pagestyle',
      maxwidth ='$maxwidth',
      ddmaxwidth ='$ddmaxwidth',
      pagepicnum ='$pagepicnum',
      imgurls='$imgurls',
      row='$prow',
      col='$pcol',
       userip='$userip',
      isrm='$isrm'{$inadd_f}
    WHERE aid='$aid'; ";
        if(!$dsql->ExecuteNoneQuery($query))
        {
            ShowMsg("An error occurred while updating the additional table `$addtable`, please contact the administrator!".$dsql->GetError(),"javascript:;");
            exit();
        }
    }

    UpIndexKey($aid, $arcrank, $typeid, $sortrank, $tags);
    $artUrl = MakeArt($aid, TRUE);
    if($artUrl=='') $artUrl = $cfg_phpurl."/view.php?aid=$aid";

    //---------------------------------
    //Return success message
    //----------------------------------
    $msg = "　　 Please choose your follow-up operation:
<a href='album_add.php?cid=$typeid'><u>Publish a new album</u></a>
&nbsp;&nbsp;
<a href='archives_do.php?channelid=$channelid&aid=".$aid."&dopost=edit'><u>View changes</u></a>
&nbsp;&nbsp;
<a href='$artUrl' target='_blank'><u>View the gallery</u></a>
&nbsp;&nbsp;
<a href='content_list.php?channelid=$channelid'><u>Manage Gallery</u></a> ";

    $wintitle = "The gallery was successfully changed!";
    $wecome_info = "Atlas Management::Change Atlas";
    $win = new OxWindow();
    $win->AddTitle("Atlas successfully changed:");
    $win->AddMsgItem($msg);
    $winform = $win->GetWindow("hand","&nbsp;",false);
    $win->Display();
}

