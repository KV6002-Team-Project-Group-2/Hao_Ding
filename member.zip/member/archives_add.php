﻿<?php

require_once(dirname(__FILE__)."/config.php");
require_once(DEDEINC."/dedetag.class.php");
require_once(DEDEINC."/userlogin.class.php");
require_once(DEDEINC."/customfields.func.php");
require_once(DEDEMEMBER."/inc/inc_catalog_options.php");
require_once(DEDEMEMBER."/inc/inc_archives_functions.php");
$channelid = isset($channelid) && is_numeric($channelid) ? $channelid : 1;
$typeid = isset($typeid) && is_numeric($typeid) ? $typeid : 0;
$mtypesid = isset($mtypesid) && is_numeric($mtypesid) ? $mtypesid : 0;
$menutype = 'content';

/*-------------
function _ShowForm(){  }
--------------*/
if(empty($dopost))
{
    $cInfos = $dsql->GetOne("Select * From `#@__channeltype` where id='$channelid'; ");
    if(!is_array($cInfos))
    {
        ShowMsg('Model does not exist','-1');
        exit();
    }

    //If the membership level or type is restricted, the option of allowing visitors to contribute is invalid
    if($cInfos['sendrank']>0 || $cInfos['usertype']!='')
    {
        CheckRank(0,0);
    }

    //Check membership level and type restrictions
    if($cInfos['sendrank']> $cfg_ml->M_Rank)
    {
        $row = $dsql->GetOne("Select membername From `#@__arcrank` where rank='".$cInfos['sendrank']."' ");
        ShowMsg("Sorry, you need [".$row['membername']."] to publish documents in this channel!","-1","0",5000);
        exit();
    }
    if($cInfos['usertype']!='' && $cInfos['usertype'] != $cfg_ml->M_MbType)
    {
        ShowMsg("Sorry, you need [".$cInfos['usertype']."account] to publish documents in this channel!","-1","0",5000);
        exit();
    }
    include(DEDEMEMBER."/templets/archives_add.htm");
    exit();
}
/*------------------------------
function _SaveArticle(){}
------------------------------*/
else if($dopost=='save')
{
    include(dirname(__FILE__).'/inc/archives_check.php');
    //Analyze and process additional table data
    $inadd_f = $inadd_v ='';
    if(!empty($dede_addonfields))
    {
        $addonfields = explode(';',$dede_addonfields);
        $inadd_f ='';
        $inadd_v ='';
        if(is_array($addonfields))
        {
            foreach($addonfields as $v)
            {
                if($v=='')
                {
                    continue;
                }
                $vs = explode(',',$v);
                if(!isset(${$vs[0]}))
                {
                    ${$vs[0]} ='';
                }

                //Automatic summary and remote image localization
                if($vs[1]=='htmltext'||$vs[1]=='textdata')
                {
                    ${$vs[0]} = AnalyseHtmlBody(${$vs[0]},$description,$vs[1]);
                }

                ${$vs[0]} = GetFieldValueA(${$vs[0]},$vs[1],0);

                $inadd_f .=','.$vs[0];
                $inadd_v .= ",'".${$vs[0]}."' ";
            }
        }
        
        if (empty($dede_fieldshash) || $dede_fieldshash != md5($dede_addonfields.$cfg_cookie_encode))
        {
            showMsg('Data verification is incorrect, the program returns','-1');
            exit();
        }
        
        // Here is a verification of the additional data submitted by the front desk
        $fontiterm = PrintAutoFieldsAdd($cInfos['fieldset'],'autofield', FALSE);
        if ($fontiterm != $inadd_f)
        {
            ShowMsg("The submission form does not match the system configuration, please resubmit!", "-1");
            exit();
        }
    }

    //Processing custom attributes of image documents
    if($litpic!='') $flag ='p';

    //Generate document ID
    $arcID = GetIndexKey($arcrank,$typeid,$sortrank,$channelid,$senddate,$mid);
    if(empty($arcID))
    {
        ShowMsg("The primary key cannot be obtained, so subsequent operations cannot be performed!","-1");
        exit();
    }

    //Save to the main table
    $inQuery = "INSERT INTO `#@__archives`(id,typeid,sortrank,flag,ismake,channel,arcrank,click,money,title,shorttitle,
color,writer,source,litpic,pubdate,senddate,mid,description,keywords,mtype)
VALUES ('$arcID','$typeid','$sortrank','$flag','$ismake','$channelid','$arcrank','0','$money','$title' ,'$shorttitle',
'$color','$writer','$source','$litpic','$pubdate','$senddate','$mid','$description','$keywords','$mtypesid') ; ";
    if(!$dsql->ExecuteNoneQuery($inQuery))
    {
        $gerr = $dsql->GetError();
        $dsql->ExecuteNoneQuery("Delete From `#@__arctiny` where id='$arcID' ");
        ShowMsg("An error occurred while saving data to the main database table `#@__archives`, please contact the administrator.","javascript:;");
        exit();
    }

    //Save to additional table
    $addtable = trim($cInfos['addtable']);
    if(empty($addtable))
    {
        $dsql->ExecuteNoneQuery("Delete From `#@__archives` where id='$arcID'");
        $dsql->ExecuteNoneQuery("Delete From `#@__arctiny` where id='$arcID'");
        ShowMsg("The main table information of the current model [{$channelid}] was not found, and the operation could not be completed.","javascript:;");
        exit();
    }
    else
    {
        $inquery = "INSERT INTO `{$addtable}`(aid,typeid,userip,redirecturl,templet{$inadd_f}) Values('$arcID','$typeid','$userip','',''{ $inadd_v})";
        if(!$dsql->ExecuteNoneQuery($inquery))
        {
            $gerr = $dsql->GetError();
            $dsql->ExecuteNoneQuery("Delete From `#@__archives` where id='$arcID'");
            $dsql->ExecuteNoneQuery("Delete From `#@__arctiny` where id='$arcID'");
            ShowMsg("An error occurred while saving data to the database additional table `{$addtable}`<br>error:{$gerr}, please contact the administrator!","javascript:;");
            exit();
        }
    }

    //Increase points
    $dsql->ExecuteNoneQuery("Update `#@__member` set scores=scores+{$cfg_sendarc_scores} where mid='".$cfg_ml->M_ID."'; ");
    //Update statistics
    countArchives($channelid);

    //Generate HTML
    InsertTags($tags,$arcID);
    $artUrl = MakeArt($arcID,true);
    if($artUrl=='')
    {
        $artUrl = $cfg_phpurl."/view.php?aid=$arcID";
    }
    
    #api{{
    if(defined('UC_API') && @include_once DEDEROOT.'/api/uc.func.php')
    {
        //Push event
        $feed['icon'] ='thread';
        $feed['title_template'] ='<b>{username} posted a piece of content on the website</b>';
        $feed['title_data'] = array('username' => $cfg_ml->M_UserName);
        $feed['body_template'] ='<b>{subject}</b><br>{message}';
        $url = !strstr($artUrl,'http://')? ($cfg_basehost.$artUrl): $artUrl;
        $feed['body_data'] = array('subject' => "<a href=\"".$url."\">$title</a>",'message' => cn_substr(strip_tags(preg_replace( "/\[.+?\]/is",'', $description)), 150));
        $feed['images'][] = array('url' => $cfg_basehost.'/images/scores.gif','link'=> $cfg_basehost);
        uc_feed_note($cfg_ml->M_LoginID,$feed);
        //Synchronous points
        $row = $dsql->GetOne("SELECT `scores`,`userid` FROM `#@__member` WHERE `mid`='".$cfg_ml->M_ID."'");
        uc_credit_note($row['userid'],$cfg_sendarc_scores);
    }
    #/aip}}
    
    //Member dynamic record
    $cfg_ml->RecordFeeds('add', $title, $description, $arcID);
    
    ClearMyAddon($arcID, $title);
    
    //Return success message
    $msg = "
    　　 Please choose your follow-up operation:
        <a href='archives_add.php?cid=$typeid&channelid=$channelid'><u>Continue to publish content</u></a>
        &nbsp;&nbsp;
        <a href='$artUrl' target='_blank'><u>View content</u></a>
        &nbsp;&nbsp;
        <a href='archives_edit.php?channelid=$channelid&aid=$arcID'><u>Change content</u></a>
        &nbsp;&nbsp;
        <a href='content_list.php?channelid={$channelid}'><u>Published content management</u></a>
        ";
    $wintitle = "Successfully published content!";
    $wecome_info = "Content Management::Publishing Content";
    $win = new OxWindow();
    $win->AddTitle("Successfully published content:");
    $win->AddMsgItem($msg);
    $winform = $win->GetWindow("hand","&nbsp;",false);
    $win->Display();
}

