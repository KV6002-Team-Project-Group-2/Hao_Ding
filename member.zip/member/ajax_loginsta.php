﻿<?php

require_once(dirname(__FILE__)."/config.php");
AjaxHead();
if($myurl == '') exit('');

$uid  = $cfg_ml->M_LoginID;

!$cfg_ml->fields['face'] && $face = ($cfg_ml->fields['sex'] == 'female')? 'dfgirl' : 'dfboy';
$facepic = empty($face)? $cfg_ml->fields['face'] : $GLOBALS['cfg_memberurl'].'/templets/images/'.$face.'.png';
?>
<div class="userinfo">
    <div class="welcome">Hi：<strong><?php echo $cfg_ml->M_UserName; ?></strong>，Login please </div>
    <div class="userface">
        <a href="<?php echo $cfg_memberurl; ?>/index.php"><img src="<?php echo $facepic;?>" width="52" height="52" /></a>
    </div>
    <div class="mylink">
        <ul>
            <li><a href="<?php echo $cfg_memberurl; ?>/guestbook_admin.php">message</a></li>
            <li><a href="<?php echo $cfg_memberurl; ?>/mystow.php">collection</a></li>
            <li><a href="<?php echo $cfg_memberurl; ?>/article_add.php">publish </a></li>
            <li><a href="<?php echo $cfg_memberurl; ?>/myfriend.php">Friends </a></li>
            <li><a href="<?php echo $cfg_memberurl; ?>/visit-history.php">Visitor Record</a></li>
            <li><a href="<?php echo $cfg_memberurl; ?>/search.php">friends</a></li>
        </ul>
    </div>
    <div class="uclink">
        <a href="<?php echo $cfg_memberurl; ?>/index.php">Member Centre</a> | 
        <a href="<?php echo $cfg_memberurl; ?>/zl.php">data</a> | 
        <a href="<?php echo $myurl;?>">space</a> | 
        <a href="<?php echo $cfg_memberurl; ?>/index_do.php?fmdo=login&dopost=exit">sign out</a> 
    </div>
</div><!-- /userinfo -->


