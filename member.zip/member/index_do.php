﻿<?php

require_once(dirname(__FILE__)."/config.php");
if(empty($dopost)) $dopost = '';
if(empty($fmdo)) $fmdo = '';

/*********************
function check_email()
*******************/
if($fmdo=='sendMail')
{
    if(!CheckEmail($cfg_ml->fields['email']) )
    {
        ShowMsg('There is an error in your email format！', '-1');
        exit();
    }
    if($cfg_ml->fields['spacesta'] != -10)
    {
        ShowMsg('Your account is not in email verification status, this operation is invalid！', '-1');
        exit();
    }
    $userhash = md5($cfg_cookie_encode.'--'.$cfg_ml->fields['mid'].'--'.$cfg_ml->fields['email']);
    $url = $cfg_basehost.(empty($cfg_cmspath) ? '/' : $cfg_cmspath)."/member/index_do.php?fmdo=checkMail&mid={$cfg_ml->fields['mid']}&userhash={$userhash}&do=1";
    $url = preg_replace("#http:\/\/#i", '', $url);
    $url = 'http://'.preg_replace("#\/\/#i", '/', $url);
    $mailtitle = "{$cfg_webname}--Member Email Verification Notification";
    $mailbody = '';
    $mailbody .= "respected user[{$cfg_ml->fields['uname']}]，Hello：\r\n";
    $mailbody .= "Welcome to register as[{$cfg_webname}]of Member.\r\n";
    $mailbody .= "To pass the registration, you must perform the last step, please click or copy the link below to the address bar to visit this address：\r\n\r\n";
    $mailbody .= "{$url}\r\n\r\n";
    $mailbody .= "Power by group 2 career system！\r\n";
  
    $headers = "From: ".$cfg_adminemail."\r\nReply-To: ".$cfg_adminemail;
    if($cfg_sendmail_bysmtp == 'Y' && !empty($cfg_smtp_server))
    {
        $mailtype = 'TXT';
        require_once(DEDEINC.'/mail.class.php');
        $smtp = new smtp($cfg_smtp_server,$cfg_smtp_port,true,$cfg_smtp_usermail,$cfg_smtp_password);
        $smtp->debug = false;
        $smtp->sendmail($cfg_ml->fields['email'],$cfg_webname ,$cfg_smtp_usermail, $mailtitle, $mailbody, $mailtype);
    }
    else
    {
        @mail($cfg_ml->fields['email'], $mailtitle, $mailbody, $headers);
    }
    ShowMsg('The email was sent successfully, please log in to your mailbox to receive it later！', '/member');
    exit();
}
else if($fmdo=='checkMail')
{
    $mid = intval($mid);
    if(empty($mid))
    {
        ShowMsg('Your validation string is illegal！', '-1');
        exit();
    }
    $row = $dsql->GetOne("SELECT * FROM `#@__member` WHERE mid='{$mid}' ");
    $needUserhash = md5($cfg_cookie_encode.'--'.$mid.'--'.$row['email']);
    if($needUserhash != $userhash)
    {
        ShowMsg('Your validation string is illegal！', '-1');
        exit();
    }
    if($row['spacesta'] != -10)
    {
        ShowMsg('Your account is not in email verification status, this operation is invalid！', '-1');
        exit();
    }
    $dsql->ExecuteNoneQuery("UPDATE `#@__member` SET spacesta=0 WHERE mid='{$mid}' ");
    // 清除会员缓存
    $cfg_ml->DelCache($mid);
    ShowMsg('The operation is successful, please log in to the system again！', 'login.php');
    exit();
}
/*********************
function Case_user()
*******************/
else if($fmdo=='user')
{

    //检查用户名是否存在
    if($dopost=="checkuser")
    {
        AjaxHead();
        $msg = '';
        $uid = trim($uid);
        if($cktype==0)
        {
            $msgtitle='User pseudonym';
        }
        else
        {
            #api{{
            if(defined('UC_API') && @include_once DEDEROOT.'/uc_client/client.php')
            {
                $ucresult = uc_user_checkname($uid);
                if($ucresult > 0)
                {
                    echo "<font color='#4E7504'><b>√Username is available</b></font>";
                }
                elseif($ucresult == -1)
                {
                    echo "<font color='red'><b>×Username is invalid</b></font>";
                }
                elseif($ucresult == -2)
                {
                    echo "<font color='red'><b>×Contains words to allow registration</b></font>";
                }
                elseif($ucresult == -3)
                {
                    echo "<font color='red'><b>×username already exists</b></font>";
                }
                exit();
            }
            #/aip}}            
            $msgtitle='username';
        }
        if($cktype!=0 || $cfg_mb_wnameone=='N') {
            $msg = CheckUserID($uid, $msgtitle);
        }
        else {
            $msg = CheckUserID($uid, $msgtitle, false);
        }
        if($msg=='ok')
        {
            $msg = "<font color='#4E7504'><b>√{$msgtitle}can use</b></font>";
        }
        else
        {
            $msg = "<font color='red'><b>×{$msg}</b></font>";
        }
        echo $msg;
        exit();
    }

    //检查email是否存在
    else  if($dopost=="checkmail")
    {
        AjaxHead();
        
        #api{{
        if(defined('UC_API') && @include_once DEDEROOT.'/uc_client/client.php')
        {
            $ucresult = uc_user_checkemail($email);
            if($ucresult > 0) {
                echo "<font color='#4E7504'><b>√can use</b></font>";
            } elseif($ucresult == -4) {
                echo "<font color='red'><b>×Email Incorrect format！</b></font>";
            } elseif($ucresult == -5) {
                echo "<font color='red'><b>×Email Registration not allowed！</b></font>";
            } elseif($ucresult == -6) {
                echo "<font color='red'><b>×Email Already registered！</b></font>";
            }
            exit();
        }
        #/aip}}    
        
        if($cfg_md_mailtest=='N')
        {
            $msg = "<font color='#4E7504'><b>√can use</b></font>";
        }
        else
        {
            if(!CheckEmail($email))
            {
                $msg = "<font color='#4E7504'><b>×Email Incorrect format</b></font>";
            }
            else
            {
                 $row = $dsql->GetOne("SELECT mid FROM `#@__member` WHERE email LIKE '$email' LIMIT 1");
                 if(!is_array($row)) {
                     $msg = "<font color='#4E7504'><b>√can use</b></font>";
                 }
                 else {
                     $msg = "<font color='red'><b>×Email Already occupied by another account！</b></font>";
                 }
            }
        }
        echo $msg;
        exit();
    }

    //引入注册页面
    else if($dopost=="regnew")
    {
        $step = empty($step)? 1 : intval(preg_replace("/[^\d]/",'', $step));
        require_once(dirname(__FILE__)."/reg_new.php");
        exit();
    }
  /***************************
  //积分换金币
  function money2s() {  }
  ***************************/
    else if($dopost=="money2s")
    {
        CheckRank(0,0);
        if($cfg_money_scores==0)
        {
            ShowMsg('The system disables the point and coin exchange function！', '-1');
            exit();
        }
        $money = empty($money) ? "" : abs(intval($money));
        if(empty($money))
        {
            ShowMsg('You did not specify how many gold coins to exchange！', '-1');
            exit();
        }
        
        $needscores = $money * $cfg_money_scores;
        if($cfg_ml->fields['scores'] < $needscores )
        {
            ShowMsg('You don’t have enough points to exchange for so many gold coins！', '-1');
            exit();
        }
        $litmitscores = $cfg_ml->fields['scores'] - $needscores;
        
        //保存记录
        $mtime = time();
        $inquery = "INSERT INTO `#@__member_operation`(`buyid` , `pname` , `product` , `money` , `mtime` , `pid` , `mid` , `sta` ,`oldinfo`)
           VALUES ('ScoresToMoney', 'Points for gold coins operation', 'stc' , '0' , '$mtime' , '0' , '{$cfg_ml->M_ID}' , '0' , '用 {$needscores} 积分兑了换金币：{$money} 个'); ";
        $dsql->ExecuteNoneQuery($inquery);
        //修改积分与金币值
        $dsql->ExecuteNoneQuery("UPDATE `#@__member` SET `scores`=$litmitscores, money= money + $money  WHERE mid='".$cfg_ml->M_ID."' ");
        
        // 清除会员缓存
        $cfg_ml->DelCache($cfg_ml->M_ID);
        ShowMsg('Successfully exchange the specified amount of gold coins！', 'operation.php');
        exit();
    }
}

/*********************
function login()
*******************/
else if($fmdo=='login')
{
    //用户登录
    if($dopost=="login")
    {
        if(!isset($vdcode))
        {
            $vdcode = '';
        }
        $svali = GetCkVdValue();
        if(preg_match("/2/",$safe_gdopen)){
            if(strtolower($vdcode)!=$svali || $svali=='')
            {
                ResetVdValue();
                ShowMsg('Verification code error！', 'index.php');
                exit();
            }
            
        }
        if(CheckUserID($userid,'',false)!='ok')
        {
            ResetVdValue();
            ShowMsg("The username you entered {$userid} illegal！","index.php");
            exit();
        }
        if($pwd=='')
        {
            ResetVdValue();
            ShowMsg("password can not be blank！","-1",0,2000);
            exit();
        }

        //检查帐号
        $rs = $cfg_ml->CheckUser($userid,$pwd);  
        
        #api{{
        if(defined('UC_API') && @include_once DEDEROOT.'/uc_client/client.php')
        {
            //检查帐号
            list($uid, $username, $password, $email) = uc_user_login($userid, $pwd);
            if($uid > 0) {
                $password = md5($password);
                //当UC存在用户,而CMS不存在时,就注册一个    
                if(!$rs) {
                    //会员的默认金币
                    $row = $dsql->GetOne("SELECT `money`,`scores` FROM `#@__arcrank` WHERE `rank`='10' ");
                    $scores = is_array($row) ? $row['scores'] : 0;
                    $money = is_array($row) ? $row['money'] : 0;
                    $logintime = $jointime = time();
                    $loginip = $joinip = GetIP();
                    $res = $dsql->ExecuteNoneQuery("INSERT INTO #@__member SET `mtype`='个人',`userid`='$username',`pwd`='$password',`uname`='$username',`sex`='男' ,`rank`='10',`money`='$money', `email`='$email', `scores`='$scores', `matt`='0', `face`='',`safequestion`='0',`safeanswer`='', `jointime`='$jointime',`joinip`='$joinip',`logintime`='$logintime',`loginip`='$loginip';");
                    if($res) {
                        $mid = $dsql->GetLastID();
                        $data = array
                        (
                        0 => "INSERT INTO `#@__member_person` SET `mid`='$mid', `onlynet`='1', `sex`='男', `uname`='$username', `qq`='', `msn`='', `tel`='', `mobile`='', `place`='', `oldplace`='0' ,
                                 `birthday`='1980-01-01', `star`='1', `income`='0', `education`='0', `height`='160', `bodytype`='0', `blood`='0', `vocation`='0', `smoke`='0', `marital`='0', `house`='0',
                       `drink`='0', `datingtype`='0', `language`='', `nature`='', `lovemsg`='', `address`='',`uptime`='0';",
                        1 => "INSERT INTO `#@__member_tj` SET `mid`='$mid',`article`='0',`album`='0',`archives`='0',`homecount`='0',`pagecount`='0',`feedback`='0',`friend`='0',`stow`='0';",
                        2 => "INSERT INTO `#@__member_space` SET `mid`='$mid',`pagesize`='10',`matt`='0',`spacename`='{$uname}Room',`spacelogo`='',`spacestyle`='person', `sign`='',`spacenews`='';",
                        3 => "INSERT INTO `#@__member_flink` SET `mid`='$mid', `title`='织梦内容管理系统', `url`='http://www.dedecms.com';"
                        );                        
                        foreach($data as $val) $dsql->ExecuteNoneQuery($val);
                    }
                }
                $rs = 1;
                $row = $dsql->GetOne("SELECT `mid`, `pwd` FROM #@__member WHERE `userid`='$username'");
                if(isset($row['mid']))
                {
                    $cfg_ml->PutLoginInfo($row['mid']);
                    if($password!=$row['pwd']) $dsql->ExecuteNoneQuery("UPDATE #@__member SET `pwd`='$password' WHERE mid='$row[mid]'");
                }
                //生成同步登录的代码
                $ucsynlogin = uc_user_synlogin($uid);
            } else if($uid == -1) {
                //当UC不存在该用而CMS存在,就注册一个.
                if($rs) {
                    $row = $dsql->GetOne("SELECT `email` FROM #@__member WHERE userid='$userid'");                    
                    $uid = uc_user_register($userid, $pwd, $row['email']);
                    if($uid > 0) $ucsynlogin = uc_user_synlogin($uid);
                } else {
                    $rs = -1;
                }
            } else {
                $rs = -1;
            }
        }
        #/aip}}        
        
        if($rs==0)
        {
            ResetVdValue();
            ShowMsg("Username does not exist！", "index.php", 0, 2000);
            exit();
        }
        else if($rs==-1) {
            ResetVdValue();
            ShowMsg("wrong password！", "index.php", 0, 2000);
            exit();
        }
        else if($rs==-2) {
            ResetVdValue();
            ShowMsg("The administrator account is not allowed to log in from the front desk！", "index.php", 0, 2000);
            exit();
        }
        else
        {
            // 清除会员缓存
            $cfg_ml->DelCache($cfg_ml->M_ID);
            if(empty($gourl) || preg_match("#action|_do#i", $gourl))
            {
                ShowMsg("Successfully log in, after 5 seconds turn to the system homepage...","index.php",0,2000);
            }
            else
            {
                $gourl = str_replace('^','&',$gourl);
                ShowMsg("Successfully logged in, now turn to the specified page...",$gourl,0,2000);
            }
            exit();
        }
    }

    //退出登录
    else if($dopost=="exit")
    {
        $cfg_ml->ExitCookie();
        #api{{
        if(defined('UC_API') && @include_once DEDEROOT.'/uc_client/client.php')
        {
            $ucsynlogin = uc_user_synlogout();
        }
        #/aip}}
        ShowMsg("Sign out successfully！","index.php",0,2000);
        exit();
    }
}
/*********************
function moodmsg()
*******************/
else if($fmdo=='moodmsg')
{
    //用户登录
    if($dopost=="sendmsg")
    {
        if(!empty($content))
        {
        $ip = GetIP();
        $dtime = time();
          $ischeck = ($cfg_mb_msgischeck == 'Y')? 0 : 1;
          if($cfg_soft_lang == 'gb2312')
          {
              $content = utf82gb(nl2br($content));
          } 
          $content = cn_substrR(HtmlReplace($content,1),360);
          //对表情进行解析
          $content = addslashes(preg_replace("/\[face:(\d{1,2})\]/is","<img src='".$cfg_memberurl."/templets/images/smiley/\\1.gif' style='cursor: pointer; position: relative;'>",$content));
          $content = RemoveXSS($content);
            $inquery = "INSERT INTO `#@__member_msg`(`mid`,`userid`,`ip`,`ischeck`,`dtime`, `msg`)
                   VALUES ('{$cfg_ml->M_ID}','{$cfg_ml->M_LoginID}','$ip','$ischeck','$dtime', '$content'); ";
            $rs = $dsql->ExecuteNoneQuery($inquery);
            if(!$rs)
            {
                $output['type'] = 'error';
                $output['data'] = 'Update failed, please try again.';
                exit();
            }
            $output['type'] = 'success';
            if($cfg_soft_lang == 'gb2312')
            {
              $content = utf82gb(nl2br($content));
            } 
            $output['data'] = stripslashes($content);
            exit(json_encode($output));
        }
    }
}
else
{
    ShowMsg("This page is prohibited from returning!","index.php");
}

