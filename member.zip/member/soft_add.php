﻿<?php
require_once(dirname(__FILE__)."/config.php");
//考虑安全原因不管是否开启游客投稿功能，都不允许用户投稿
CheckRank(0, 0);
if($cfg_mb_lit=='Y')
{
    ShowMsg("Since the system has opened the lite version of the member space, the function you are accessing is unavailable！","-1");
    exit();
}
require_once(DEDEINC."/dedetag.class.php");
require_once(DEDEINC."/userlogin.class.php");
require_once(DEDEINC."/customfields.func.php");
require_once(DEDEMEMBER."/inc/inc_catalog_options.php");
require_once(DEDEMEMBER."/inc/inc_archives_functions.php");
$channelid = isset($channelid) && is_numeric($channelid) ? $channelid : 3;
$typeid = isset($typeid) && is_numeric($typeid) ? $typeid : 0;
$menutype = 'content';

/*-------------
function _ShowForm(){  }
--------------*/
if(empty($dopost))
{
    $cInfos = $dsql->GetOne("SELECT * FROM `#@__channeltype`  WHERE id='$channelid'; ");
    if(!is_array($cInfos))
    {
        ShowMsg('Incorrect model', '-1');
        exit();
    }

    //如果限制了会员级别或类型，则允许游客投稿选项无效
    if($cInfos['sendrank']>0 || $cInfos['usertype']!='')
    {
        CheckRank(0, 0);
    }

    //检查会员等级和类型限制
    if($cInfos['sendrank'] > $cfg_ml->M_Rank)
    {
        $row = $dsql->GetOne("Select membername From `#@__arcrank` where rank='".$cInfos['sendrank']."' ");
        ShowMsg("Sorry, you need [".$row['membername']."] to publish documents in this channel！","-1","0",5000);
        exit();
    }
    if($cInfos['usertype']!='' && $cInfos['usertype'] != $cfg_ml->M_MbType)
    {
        ShowMsg("Sorry, you need [".$cInfos['usertype']."account] to publish documents in this channel！","-1","0",5000);
        exit();
    }
    include(DEDEMEMBER."/templets/soft_add.htm");
    exit();
}

/*------------------------------
function _SaveArticle(){  }
------------------------------*/
else if($dopost=='save')
{
    $description = '';
    include(DEDEMEMBER.'/inc/archives_check.php');

    //生成文档ID
    $arcID = GetIndexKey($arcrank,$typeid,$sortrank,$channelid,$senddate,$mid);
    if(empty($arcID))
    {
        ShowMsg("Unable to obtain the primary key, so subsequent operations cannot be performed！","-1");
        exit();
    }
    
    //分析处理附加表数据
    $inadd_f = '';
    $inadd_v = '';
    if(!empty($dede_addonfields))
    {
        $addonfields = explode(';',$dede_addonfields);
        $inadd_f = '';
        $inadd_v = '';
        if(is_array($addonfields))
        {
            foreach($addonfields as $v)
            {
                if($v=='')
                {
                    continue;
                }else if($v == 'templet')
                {
                    ShowMsg("The field you saved is wrong, please check！","-1");
                    exit();    
                }
                $vs = explode(',',$v);
                if(!isset(${$vs[0]}))
                {
                    ${$vs[0]} = '';
                }
                else if($vs[1]=='htmltext'||$vs[1]=='textdata')

                //HTML文本特殊处理
                {
                    ${$vs[0]} = AnalyseHtmlBody(${$vs[0]},$description,$litpic,$keywords,$vs[1]);
                }
                else
                {
                    if(!isset(${$vs[0]}))
                    {
                        ${$vs[0]} = '';
                    }
                    ${$vs[0]} = GetFieldValueA(${$vs[0]},$vs[1],$arcID);
                }
                $inadd_f .= ','.$vs[0];
                $inadd_v .= " ,'".${$vs[0]}."' ";
            }
        }
        
        if (empty($dede_fieldshash) || $dede_fieldshash != md5($dede_addonfields.$cfg_cookie_encode))
        {
            showMsg('The data check is incorrect, the program returns', '-1');
            exit();
        }
        
        // 这里对前台提交的附加数据进行一次校验
        $fontiterm = PrintAutoFieldsAdd($cInfos['fieldset'],'autofield', FALSE);
        if ($fontiterm != $inadd_f)
        {
            ShowMsg("The submitted form does not match the system configuration, please resubmit！", "-1");
            exit();
        }
    }

    //处理图片文档的自定义属性
    if($litpic!='')
    {
        $flag = 'p';
    }
    $body = HtmlReplace($body,-1);

    //保存到主表
    $inQuery = "INSERT INTO `#@__archives`(id,typeid,sortrank,flag,ismake,channel,arcrank,click,money,title,shorttitle,
color,writer,source,litpic,pubdate,senddate,mid,description,keywords)
VALUES ('$arcID','$typeid','$sortrank','$flag','$ismake','$channelid','$arcrank','0','$money','$title','$shorttitle',
'$color','$writer','$source','$litpic','$pubdate','$senddate','$mid','$description','$keywords'); ";
    if(!$dsql->ExecuteNoneQuery($inQuery))
    {
        $gerr = $dsql->GetError();
        $dsql->ExecuteNoneQuery("Delete From `#@__arctiny` where id='$arcID' ");
        ShowMsg("An error occurred while saving data to the main database table `#@__archives`, please contact the administrator.","javascript:;");
        exit();
    }

    //软件链接列表
    $softurl1 = stripslashes($softurl1);
    $softurl1 = str_replace(array("{dede:","{/dede:","}"), "#", $softurl1);
    $urls = '';
    if($softurl1!='')
    {
        $urls .= "{dede:link islocal='1' text='{$servermsg1}'} $softurl1 {/dede:link}\r\n";
    }
    for($i=2; $i<=12; $i++)
    {
        if(!empty(${'softurl'.$i}))
        {
            $servermsg = str_replace("'","",stripslashes(${'servermsg'.$i}));
            $softurl = stripslashes(${'softurl'.$i});
			$softurl = str_replace(array("{dede:","{/dede:","}"), "#", $softurl);
            if($servermsg=='')
            {
                $servermsg = 'download link'.$i;
            }
            if($softurl!='' && $softurl!='http://')
            {
                $urls .= "{dede:link text='$servermsg'} $softurl {/dede:link}\r\n";
            }
        }
    }
    $urls = addslashes($urls);
    $softsize = $softsize.$unit;

    //保存到附加表
    $needmoney = @intval($needmoney);
    if($needmoney > 100) $needmoney = 100;
    $cts = $dsql->GetOne("SELECT addtable FROM `#@__channeltype` WHERE id='$channelid' ");
    $addtable = trim($cts['addtable']);
    if(empty($addtable))
    {
        $dsql->ExecuteNoneQuery("DELETE FROM `#@__archives` WHERE id='$arcID'");
        $dsql->ExecuteNoneQuery("DELETE FROM `#@__arctiny` WHERE id='$arcID'");
        ShowMsg("Cannot find the main table information of the current model [{$channelid}], the operation cannot be completed！","javascript:;");
        exit();
    }
    $inQuery = "INSERT INTO `$addtable`(aid,typeid,filetype,language,softtype,accredit,
    os,softrank,officialUrl,officialDemo,softsize,softlinks,introduce,userip,templet,redirecturl,daccess,needmoney{$inadd_f})
    VALUES ('$arcID','$typeid','$filetype','$language','$softtype','$accredit',
    '$os','$softrank','$officialUrl','$officialDemo','$softsize','$urls','$body','$userip','','','0','$needmoney'{$inadd_v});";
    if(!$dsql->ExecuteNoneQuery($inQuery))
    {
        $gerr = $dsql->GetError();
        $dsql->ExecuteNoneQuery("DELETE FROM `#@__archives` WHERE id='$arcID'");
        $dsql->ExecuteNoneQuery("DELETE FROM `#@__arctiny` WHERE id='$arcID'");
        echo $inQuery;
        exit();
        ShowMsg("An error occurred while saving the data to the database additional table `{$addtable}`, please submit the relevant information to the DedeCms official".str_replace('"','',$gerr),"javascript:;");
        exit();
    }

    //增加积分
    $cfg_sendarc_scores = intval($cfg_sendarc_scores);
    $dsql->ExecuteNoneQuery("UPDATE `#@__member` set scores=scores+{$cfg_sendarc_scores} WHERE mid='".$cfg_ml->M_ID."' ; ");
    //更新统计
    countArchives($channelid);
    
    //生成HTML
    InsertTags($tags,$arcID);
    $artUrl = MakeArt($arcID, TRUE);
    if($artUrl=='')
    {
        $artUrl = $cfg_phpurl."/view.php?aid=$arcID";
    }

    #api{{
    if(defined('UC_API') && @include_once DEDEROOT.'/api/uc.func.php')
    {
        //推送事件
        $feed['icon'] = 'thread';
        $feed['title_template'] = '<b>{username} Shared a piece of software on the website</b>';
        $feed['title_data'] = array('username' => $cfg_ml->M_UserName);
        $feed['body_template'] = '<b>{subject}</b><br>{message}';
        $url = !strstr($artUrl,'http://') ? ($cfg_basehost.$artUrl) : $artUrl;
        $feed['body_data'] = array('subject' => "<a href=\"".$url."\">$title</a>", 'message' => cn_substr(strip_tags(preg_replace("/\[.+?\]/is", '', $description)), 150));        
        $feed['images'][] = array('url' => $cfg_basehost.'/images/scores.gif', 'link'=> $cfg_basehost);
        uc_feed_note($cfg_ml->M_LoginID,$feed);
        //同步积分
        uc_credit_note($cfg_ml->M_LoginID, $cfg_sendarc_scores);
    }
    #/aip}}
    
    //会员动态记录
    $cfg_ml->RecordFeeds('addsoft',$title,$description,$arcID);
    
    ClearMyAddon($arcID, $title);
    
    //返回成功信息
    $msg = "
        请选择你的后续操作：
        <a href='soft_add.php?cid=$typeid'><u>Continue to release software</u></a>
        &nbsp;&nbsp;
        <a href='$artUrl' target='_blank'><u>View software</u></a>
        &nbsp;&nbsp;
        <a href='soft_edit.php?channelid=$channelid&aid=$arcID'><u>Change software</u></a>
        &nbsp;&nbsp;
        <a href='content_list.php?channelid={$channelid}'><u>Released software management</u></a>
        ";
    $wintitle = "Successfully published the article! ";
     $wecome_info = "Software Management::Release Software";
     $win = new OxWindow();
     $win->AddTitle("Successfully released the software：");
    $win->AddMsgItem($msg);
    $winform = $win->GetWindow("hand", "&nbsp;", FALSE);
    $win->Display();
}

