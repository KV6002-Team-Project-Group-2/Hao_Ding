﻿<?php
        $add_channel_menu = array();
        //If visiting for tourists, do not enable the left menu
        if(!empty($cfg_ml->M_ID))
        {
            $channelInfos = array();
            $dsql->Execute('addmod',"SELECT id,nid,typename,useraddcon,usermancon,issend,issystem,usertype,isshow FROM `#@__channeltype` ");
            while($menurow = $dsql->GetArray('addmod'))
            {
                $channelInfos[$menurow['nid']] = $menurow;
                //Disabled model
                if($menurow['isshow']==0)
                {
                    continue;
                }
                //Other situations
                if($menurow['issend']!=1 || $menurow['issystem']==1
                || (!preg_match("#".$cfg_ml->M_MbType."#", $menurow['usertype']) && trim($menurow['usertype'])!=''))
                {
                    continue;
                }
                $menurow['ddcon'] = empty($menurow['useraddcon'])?'archives_add.php': $menurow['useraddcon'];
                $menurow['list'] = empty($menurow['usermancon'])?'content_list.php': $menurow['usermancon'];
                $add_channel_menu[] = $menurow;
            }
            unset($menurow);
?>
 
      <!-- Content Center Menu-->
      <?php
if($menutype =='mydede')

      {
      ?>
   
        <?php
        //Whether to enable article submission
        if($channelInfos['article']['issend']==1 && $channelInfos['article']['isshow']==1)
        {
        ?>
                  <dd><a href="content_list.php?channelid=1" title="Published Article">Article</a><span><a href="article_add.php" title="Article Publish">Post</a></span></dd>
        <?php
      }
        //Whether to enable atlas submission
        if($channelInfos['image']['issend']==1 && $cfg_mb_album=='Y' && $channelInfos['image']['isshow']==1
        && ($channelInfos['image']['usertype']=='' || preg_match("#".$cfg_ml->fields['mtype']."#", $channelInfos['image'][' usertype'])))
        {
        ?>
          
          
          <dd><a href="content_list.php?channelid=2" title="Manage Atlas">Jobs</a><span><a href="album_add.php" title="Atlas upload" >Post</a></span></dd>
<?php
}

//Whether to allow submission of custom models

if($cfg_mb_sendall=='Y')
{
?>
 
  <?php
foreach($add_channel_menu as $nnarr) {
?>
<!--<dd><a href="<?php echo $nnarr['list'];?>?channelid=<?php echo $nnarr['id'];?>" title="Released<?php echo $nnarr['typename'];?>"><?php echo $nnarr['typename'];?>Manage</a><span><a href='archives_do.php?dopost=addArc&channelid=<?php echo $nnarr['id'];?>' title="Publish<?php echo $nnarr['typename'];?>">Post</a></span></dd>-->
<?php
}
}
?>

    <dd><a href="mystow.php"><b></b>My Fav</a></dd>
         <?php
      }
      ?>
      <!-- My Dream Weaving Menu-->
      <?php
      if($menutype =='content')
      {
      ?>
                  <dd><a href="content_list.php?channelid=1" title="Published Article">Article</a><span><a href="article_add.php" title="Publish Article">Post</a></span></dd>
          <dd><a href="content_list.php?channelid=2" title="Manage Atlas">Jobs</a><span><a href="article_add.php" title="Atlas upload" >Post</a></span></dd>
    <dd><a href="mystow.php"><b></b>My Fav</a></dd>

<!--<?php
        if($cfg_feedback_forbid=='N')
        {
          //<dd class="icon feedback"><a href='../member/myfeedback.php'>Comment</a></dd>
        }
        $dsql->Execute('nn','Select indexname,indexurl From `#@__sys_module` where ismember=1');
        while($nnarr = $dsql->GetArray('nn'))
        {
        @preg_match("/\/(.+?)\//is", $nnarr['indexurl'],$matches);
        $nnarr['class'] = isset($matches[1])? $matches[1]:'channel';
        $nnarr['indexurl'] = str_replace("**","=",$nnarr['indexurl']);
        ?>
        <dd class="<?php echo $nnarr['class'];?>"><a href="<?php echo $nnarr['indexurl']; ?>"><b></b>< ?php echo $nnarr['indexname']; ?>Module</a></dd>
        <?php
        }
        ?>-->
         <?php
      }
      ?>
      <!-- System setting menu-->
      <?php
      if($menutype =='config')
      {
      ?>
         <dd ><a href="zh.php"><b></b>Basic info</a></dd>
<dd ><a href="zl.php"><b></b>Data</a></dd>
<!--<dd><a href="tx.php"><b></b>Portrait</a></dd>-->
          <dd><a href="fl.php"><b></b>Classification</a></dd>
         <dd><a href="kj.php"><b></b>Space S</a></dd>
        <dd><a href="fg.php"><b></b>Style</a></dd>
         
        <?php
      }
      ?>
       <?php
    }
    ?>
   