﻿function checkSubmit()
{

	if(document.addcontent.title.value==""){
		alert("Name is required！");
		document.addcontent.title.focus();
		return false;
	}

	if(document.addcontent.typeid.value==0){
		alert("Affiliation column must be selected！");
		return false;
	}

	if(document.addcontent.typeid.options && document.addcontent.typeid.options[document.addcontent.typeid.selectedIndex].className!='option3')
	{
		alert("Affiliated column must select the item with white background！");
		return false;
	}

	if(document.addcontent.vdcode.value==""){
		document.addcontent.vdcode.focus();
		alert("verification code must be filled！");
		return false;
	}

}

