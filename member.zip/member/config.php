﻿<?php


//XSS filtering for member center operations
function XSSClean($val) {
    global $cfg_soft_lang;
    if($cfg_soft_lang=='gb2312') gb2utf8($val);
    if (is_array($val))
    {
        foreach ($val as $key => $value)
        //while (list($key) = each($val))
        {
            if(in_array($key,array('tags','body','dede_fields','dede_addonfields','dopost'))) continue;
            $val[$key] = XSSClean($val[$key]);
        }
        return $val;
    }
    $val = preg_replace('/([\x00-\x08,\x0b-\x0c,\x0e-\x19])/', '', $val);
    $search = 'abcdefghijklmnopqrstuvwxyz';
    $search .= 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $search .= '1234567890!@#$%^&*()';
    $search .= '~`";:?+/={}[]-_|\'\\';
    for ($i = 0; $i < strlen($search); $i++) {
      $val = preg_replace('/(&#[xX]0{0,8}'.dechex(ord($search[$i])).';?)/i', $search[$i], $val); // with a ;
      $val = preg_replace('/(&#0{0,8}'.ord($search[$i]).';?)/', $search[$i], $val); // with a ;
    }
    
    $val = str_replace("`","‘",$val);
    $val = str_replace("'","‘",$val);
    $val = str_replace("\"","“",$val);
    $val = str_replace(",","，",$val);
    $val = str_replace("(","（",$val);
    $val = str_replace(")","）",$val);

    $ra1 = array('javascript', 'vbscript', 'expression', 'applet', 'meta', 'xml', 'blink', 'link', 'style', 'script', 'embed', 'object', 'iframe', 'frame', 'frameset', 'ilayer', 'layer', 'bgsound', 'title', 'base');
    $ra2 = array('onabort', 'onactivate', 'onafterprint', 'onafterupdate', 'onbeforeactivate', 'onbeforecopy', 'onbeforecut', 'onbeforedeactivate', 'onbeforeeditfocus', 'onbeforepaste', 'onbeforeprint', 'onbeforeunload', 'onbeforeupdate', 'onblur', 'onbounce', 'oncellchange', 'onchange', 'onclick', 'oncontextmenu', 'oncontrolselect', 'oncopy', 'oncut', 'ondataavailable', 'ondatasetchanged', 'ondatasetcomplete', 'ondblclick', 'ondeactivate', 'ondrag', 'ondragend', 'ondragenter', 'ondragleave', 'ondragover', 'ondragstart', 'ondrop', 'onerror', 'onerrorupdate', 'onfilterchange', 'onfinish', 'onfocus', 'onfocusin', 'onfocusout', 'onhelp', 'onkeydown', 'onkeypress', 'onkeyup', 'onlayoutcomplete', 'onload', 'onlosecapture', 'onmousedown', 'onmouseenter', 'onmouseleave', 'onmousemove', 'onmouseout', 'onmouseover', 'onmouseup', 'onmousewheel', 'onmove', 'onmoveend', 'onmovestart', 'onpaste', 'onpropertychange', 'onreadystatechange', 'onreset', 'onresize', 'onresizeend', 'onresizestart', 'onrowenter', 'onrowexit', 'onrowsdelete', 'onrowsinserted', 'onscroll', 'onselect', 'onselectionchange', 'onselectstart', 'onstart', 'onstop', 'onsubmit', 'onunload');
    $ra = array_merge($ra1, $ra2);

    $found = true; 
    while ($found == true) {
      $val_before = $val;
      for ($i = 0; $i < sizeof($ra); $i++) {
         $pattern = '/';
         for ($j = 0; $j < strlen($ra[$i]); $j++) {
            if ($j > 0) {
               $pattern .= '(';
               $pattern .= '(&#[xX]0{0,8}([9ab]);)';
               $pattern .= '|';
               $pattern .= '|(&#0{0,8}([9|10|13]);)';
               $pattern .= ')*';
            }
            $pattern .= $ra[$i][$j];
         }
         $pattern .= '/i';
         $replacement = substr($ra[$i], 0, 2).'<x>'.substr($ra[$i], 2);
         $val = preg_replace($pattern, $replacement, $val); 
         if ($val_before == $val) {
            $found = false;
         }
      }
    }
    if($cfg_soft_lang=='gb2312') utf82gb($val);
    return $val;
}
$_GET = XSSClean($_GET);
$_POST = XSSClean($_POST);
$_REQUEST = XSSClean($_REQUEST);
$_COOKIE = XSSClean($_COOKIE);

require_once(dirname(__FILE__).'/../include/common.inc.php');
require_once(DEDEINC.'/filter.inc.php');
require_once(DEDEINC.'/memberlogin.class.php');
require_once(DEDEINC.'/dedetemplate.class.php');

//Get the current script name, if your system has disabled the $_SERVER variable, please change this option yourself
$dedeNowurl = $s_scriptName ='';
$dedeNowurl = GetCurUrl();
$dedeNowurls = explode('?', $dedeNowurl);
$s_scriptName = $dedeNowurls[0];
$menutype ='';
$menutype_son ='';
$gourl = empty($gourl)? "": RemoveXSS($gourl);

//Check whether the membership function is open
if($cfg_mb_open=='N')
{
    ShowMsg("The system has turned off the membership function, so you cannot access this page!","javascript:;");
    exit();
}
$keeptime = isset($keeptime) && is_numeric($keeptime)? $keeptime: -1;
$cfg_ml = new MemberLogin($keeptime);

//Determine whether the user is logged in
$myurl ='';
if($cfg_ml->IsLogin())
{
    $myurl = $cfg_memberurl."/index.php?uid=".urlencode($cfg_ml->M_LoginID);
    if(!preg_match("#^http:#i", $myurl)) $myurl = $cfg_basehost.$myurl;
}

/**
 * Check whether the user has permission to perform an operation
 *
 * @param int $rank permission value
 * @param int $money gold coin
 * @param bool $needinfo Do you need to fill in detailed information
 * @return void
 */
function CheckRank($rank=0, $money=0, $needinfo=TRUE)
{
    global $cfg_ml,$cfg_memberurl,$cfg_mb_reginfo,$cfg_mb_spacesta;
    if(!$cfg_ml->IsLogin())
    {
        header("Location:{$cfg_memberurl}/login.php?gourl=".urlencode(GetCurUrl()));
        exit();
    }
    else
    {
        if($cfg_mb_reginfo =='Y' && $needinfo)
        {
            //If registration details are enabled
            if($cfg_ml->fields['spacesta'] == 0 || $cfg_ml->fields['spacesta'] == 1)
            {
                ShowMsg("Details have not been completed yet, please complete...","{$cfg_memberurl}/index_do.php?fmdo=user&dopost=regnew&step=2",0,1000);
                exit;
            }
        }
        if($cfg_mb_spacesta =='-10')
        {
            //If registration email verification is enabled
            if($cfg_ml->fields['spacesta'] =='-10')
            {
                  $msg="You haven't done email verification yet, please check your email address...</br>Resend email verification<a href='/member/index_do.php?fmdo=sendMail'><font color='red'> Click here</font></a>";
                ShowMsg($msg,"-1",0,5000);
                exit;
            }
        }
        if($cfg_ml->M_Rank <$rank)
        {
            $needname = "";
            if($cfg_ml->M_Rank==0)
            {
                $row = $dsql->GetOne("SELECT membername FROM #@__arcrank WHERE rank='$rank'");
                $myname = "Ordinary Member";
                $needname = $row['membername'];
            }
            else
            {
                $dsql->SetQuery("SELECT membername From #@__arcrank WHERE rank='$rank' OR rank='".$cfg_ml->M_Rank."' ORDER BY rank DESC");
                $dsql->Execute();
                $row = $dsql->GetObject();
                $needname = $row->membername;
                if($row = $dsql->GetObject())
                {
                    $myname = $row->membername;
                }
                else
                {
                    $myname = "Ordinary Member";
                }
            }
            ShowMsg("Sorry, you need: <span style='font-size:11pt;color:red'>$needname</span> to access this page.<br>Your current level is: <span style='font- size:11pt;color:red'>$myname</span> .","-1",0,5000);
            exit();
        }
        else if($cfg_ml->M_Money <$money)
        {
            ShowMsg("Sorry, it takes gold coins: <span style='font-size:11pt;color:red'>$money</span> to access this page.<br>The gold coins you currently own are: <span style= 'font-size:11pt;color:red'>".$cfg_ml->M_Money."</span> .","-1",0,5000);
            exit();
        }
    }
}

/**
 *  更新文档统计
 *
 * @access    public
 * @param     int  $channelid  频道模型id
 * @return    string
 */
function countArchives($channelid)
{
    global $cfg_ml,$dsql;
    $id = (int)$channelid;
    if($cfg_ml->IsLogin())
    {
        $channeltype = array(1 => 'article',2 => 'album',3 => 'soft',-8 => 'infos');
        if(isset($channeltype[$id]))
        {
            $_field = $channeltype[$id];
        }
        else
        {
            $_field = 'articles';
        }
        $row = $dsql->GetOne("SELECT COUNT(*) AS nums FROM #@__archives WHERE channel='$id' AND mid='".$cfg_ml->M_ID."'");
        
        $dsql->ExecuteNoneQuery("UPDATE #@__member_tj SET ".$_field."='".$row['nums']."' WHERE mid='".$cfg_ml->M_ID."'");
    }
    else
    {
        return FALSE;
    }
}

